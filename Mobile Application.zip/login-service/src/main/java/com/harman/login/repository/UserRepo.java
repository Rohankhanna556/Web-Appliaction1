package com.harman.login.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.harman.login.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	User findByName(String userName);

}
